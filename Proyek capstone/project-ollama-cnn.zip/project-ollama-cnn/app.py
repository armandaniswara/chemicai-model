from fastapi import FastAPI
from pydantic import BaseModel
import tensorflow as tf
import numpy as np
import requests
import os

# ======== DOWNLOAD MODEL CNN DARI GOOGLE DRIVE ========
MODEL_URL = "https://drive.google.com/uc?export=download&id=16KxUgya37GrvE-q2FgbAJdwFe-QMaQPR"
MODEL_PATH = "saved_model.keras"   # <-- AMAN untuk backend lokal

def download_model():
    if not os.path.exists(MODEL_PATH):
        print("📥 Downloading model from Google Drive...")
        response = requests.get(MODEL_URL)
        with open(MODEL_PATH, "wb") as f:
            f.write(response.content)
        print("✅ Model downloaded successfully!")

download_model()

# ======== LOAD MODEL CNN ========
model = tf.keras.models.load_model(MODEL_PATH, compile=False)

app = FastAPI()

class Input(BaseModel):
    text: str

def call_ollama(prompt: str) -> str:
    """Mengirim prompt ke Ollama lokal."""
    response = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": "llama3.1",
            "prompt": prompt
        }
    )
    data = response.json()
    return data["response"]

@app.post("/predict")
def predict(input: Input):

    user_input = input.text

    # === STEP 1: Reasoning oleh Ollama ===
    reasoning = call_ollama(f"""
    Analisa input ini dan buatkan representasi singkat: {user_input}.
    Output harus berupa deskripsi senyawa singkat saja.
    """)

    # === STEP 2: Preprocessing untuk CNN ===
    cnn_input = np.array([[len(reasoning)]])  
    cnn_input = np.expand_dims(cnn_input, axis=0)

    # === STEP 3: Prediksi CNN ===
    prediction = model.predict(cnn_input)
    pred_class = int(np.argmax(prediction))

    labels = ["Obat Sakit Kepala", "Obat Flu", "Obat Batuk"]
    final_label = labels[pred_class]

    return {
        "input_user": user_input,
        "ollama_reasoning": reasoning,
        "cnn_prediction": final_label
    }