# AI Agent Backend – Ollama + CNN Medicine Classifier

Backend ini menggabungkan Large Language Model (LLM) lokal (Ollama) dengan model CNN (Keras TensorFlow) 
untuk menghasilkan rekomendasi kategori obat berdasarkan deskripsi senyawa.

---

## 🚀 Fitur Utama

- Reasoning menggunakan model Ollama lokal (contoh: llama3.1)
- Prediksi menggunakan model CNN Keras yang otomatis diunduh dari Google Drive
- FastAPI untuk endpoint REST API
- Bisa diintegrasikan ke frontend web, mobile, atau sistem lain

---

## 📦 Instalasi

1. Clone folder ini

2. Install dependencies:
pip install -r requirements.txt


3. Pastikan Ollama sudah ter-install di komputer:
https://ollama.com/download

4. Jalankan model LLM di Ollama:
ollama run llama3.1


5. Jalankan server FastAPI:
uvicorn app:app --reload


6. API Docs:
http://localhost:8000/docs


---

## 🧠 Cara Kerja

1. User mengirim teks deskripsi
2. Backend mengirim prompt ke Ollama → menghasilkan *reasoning*
3. Reasoning di-preprocess menjadi input CNN
4. CNN memprediksi kategori obat:
   - Obat Sakit Kepala
   - Obat Flu
   - Obat Batuk
5. Backend mengembalikan hasil ke frontend

---

## 🔥 Example Request

### Endpoint

POST /predict

### Body JSON
{
"text": "struktur mirip parasetamol dengan gugus fenol"
}

### Example Response
{
"input_user": "...",
"ollama_reasoning": "...",
"cnn_prediction": "Obat Sakit Kepala"
}


---

## 📌 Catatan Penting

- Model CNN otomatis diunduh saat pertama kali server dijalankan
- Ollama harus berjalan di port default `11434`
- Untuk mengganti model LLM: ubah `"model": "llama3.1"` di app.py

---

## 🧩 Integrasi Frontend

Frontend dapat memanggil API seperti:

fetch("http://localhost:8000/predict
", {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify({ text: userText })
})
.then(res => res.json())
.then(data => console.log(data));

---

## 👨‍💻 Developer: Raymond

